# Libreria transformadora de texto

_Una libreria que cambia el color del texto en español en el terminal_


## Comenzando 🚀

_instalar la libreria_

~~~
pip install color_latam
~~~

*Modo de uso

Ejemplo:

example.py
~~~
import color_latam

palabra = input("Ingresa una palabra: ")
resultado = color.rojo(palabra)
resul = color.verde(palabra)


print(resultado)
print("---")
print(resul)

~~~


