from .color import rojo,verde,amarillo,azul,negro,magenta
