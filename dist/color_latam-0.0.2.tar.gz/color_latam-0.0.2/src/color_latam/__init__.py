from .color_latam import rojo,verde,amarillo,azul,negro,magenta
